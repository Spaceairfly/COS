﻿Public Class frmMain
    Dim Food1 As String = "Fried Noodles"
    Dim Food2 As String = "Fried Noodles"
    Dim Food3 As String = "Fried Noodles"
    Dim Food4 As String = "Fried Noodles"
    Dim Food5 As String = "Fried Noodles"
    Dim FoodP1 As Double = 5
    Dim FoodP2 As Double = 4.5
    Dim FoodP3 As Double = 10
    Dim FoodP4 As Double = 3
    Dim FoodP5 As Double = 7
    Dim Drink1 As String = "Smoothie"
    Dim Drink2 As String = "Smoothie"
    Dim Drink3 As String = "Smoothie"
    Dim Drink4 As String = "Smoothie"
    Dim DrinkP1 As Double = 5
    Dim DrinkP2 As Double = 4.5
    Dim DrinkP3 As Double = 10
    Dim DrinkP4 As Double = 3
    Dim TaxV As Double = 0.06
    Public TotalPayable As Double = 0.00

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Height = 1080
        Me.Width = 1920
        lbluserid.Text = frmlogin.loginuser
        txt1.Text = 0 : txt2.Text = 0 : txt3.Text = 0 : txt4.Text = 0 : txt5.Text = 0 : txt6.Text = 0 : txt7.Text = 0 : txt8.Text = 0 : txt9.Text = 0
        txtTotal.Text = 0
        lblFood1.Text = Food1
        lblFood1.Text = Food1
        lblFood1.Text = Food1
        lblFood1.Text = Food1
        lblFood1.Text = Food1
        lblFoodP1.Text = FoodP1
        lblFoodP2.Text = FoodP2
        lblFoodP3.Text = FoodP3
        lblFoodP4.Text = FoodP4
        lblFoodP5.Text = FoodP5
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmlogin.Show()
        Me.Close()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lbTittle.Click

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles lbluserid.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txt1.Text = AddReduceQty(1, txt1.Text)
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        txt1.Text = AddReduceQty(0, txt1.Text)
    End Sub


    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        txt2.Text = AddReduceQty(1, txt2.Text)
    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Calculate.Click
        Dim TotalValue, TotTax, NetTotal As Double
        TotalValue = (Val(txt1.Text) * FoodP1) + (Val(txt2.Text) * FoodP2) + (Val(txt3.Text) * FoodP3) + (Val(txt4.Text) * FoodP4) + (Val(txt5.Text) * FoodP5) _
                      + (Val(txt6.Text) * DrinkP1) + (Val(txt7.Text) * DrinkP2) + (Val(txt8.Text) * DrinkP3) + (Val(txt9.Text) * DrinkP4)
        txtTotal.Text = Str(TotalValue)
        TotTax = TotalValue * TaxV
        NetTotal = TotalValue + TotTax
        txtTax.Text = Str(TotTax)
        txtNet.Text = Str(NetTotal)
        TotalPayable = NetTotal

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        txt3.Text = AddReduceQty(1, txt3.Text)
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        txt4.Text = AddReduceQty(1, txt4.Text)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        txt5.Text = AddReduceQty(1, txt5.Text)
    End Sub

    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        txt2.Text = AddReduceQty(0, txt2.Text)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        txt3.Text = AddReduceQty(0, txt3.Text)
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        txt4.Text = AddReduceQty(0, txt4.Text)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        txt5.Text = AddReduceQty(0, txt5.Text)
    End Sub

    Private Sub Button20_Click_1(sender As Object, e As EventArgs) Handles Button20.Click
        frmPay.Show()
        Me.Close()
    End Sub
End Class