﻿Module modmain
    Function AddReduceQty(ar As Integer, t As String) As String
        Dim item1tmp As Integer
        Dim result As String
        If ar = 1 Then
            item1tmp = Val(t)
            item1tmp = item1tmp + 1
            If item1tmp > 10 Then
                MessageBox.Show("Maximum Qty = 10")
                item1tmp = 10
            End If
            result = Str(item1tmp)
        Else
            item1tmp = Val(t)
            item1tmp = item1tmp - 1
            If item1tmp < 0 Then
                MessageBox.Show("Negative Value Not Allowed")
                item1tmp = 0
            End If
            result = Str(item1tmp)
        End If
        AddReduceQty = result
    End Function
End Module
