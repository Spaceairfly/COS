﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbluserid = New System.Windows.Forms.Label()
        Me.lbTittle = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.txt3 = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.txt5 = New System.Windows.Forms.TextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.txt4 = New System.Windows.Forms.TextBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.txt9 = New System.Windows.Forms.TextBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.txt8 = New System.Windows.Forms.TextBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.txt7 = New System.Windows.Forms.TextBox()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.txt6 = New System.Windows.Forms.TextBox()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.lblFood1 = New System.Windows.Forms.Label()
        Me.lblFood3 = New System.Windows.Forms.Label()
        Me.lblFood4 = New System.Windows.Forms.Label()
        Me.lblFood5 = New System.Windows.Forms.Label()
        Me.lblFood2 = New System.Windows.Forms.Label()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.lblFoodP2 = New System.Windows.Forms.Label()
        Me.lblFoodP5 = New System.Windows.Forms.Label()
        Me.lblFoodP4 = New System.Windows.Forms.Label()
        Me.lblFoodP3 = New System.Windows.Forms.Label()
        Me.lblFoodP1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Calculate = New System.Windows.Forms.Button()
        Me.txtTax = New System.Windows.Forms.TextBox()
        Me.txtNet = New System.Windows.Forms.TextBox()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1787, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(98, 98)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lbluserid)
        Me.Panel1.Controls.Add(Me.lbTittle)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1898, 128)
        Me.Panel1.TabIndex = 1
        '
        'lbluserid
        '
        Me.lbluserid.AutoSize = True
        Me.lbluserid.Location = New System.Drawing.Point(3, 16)
        Me.lbluserid.Name = "lbluserid"
        Me.lbluserid.Size = New System.Drawing.Size(0, 69)
        Me.lbluserid.TabIndex = 2
        '
        'lbTittle
        '
        Me.lbTittle.AutoSize = True
        Me.lbTittle.Location = New System.Drawing.Point(584, 16)
        Me.lbTittle.Name = "lbTittle"
        Me.lbTittle.Size = New System.Drawing.Size(782, 69)
        Me.lbTittle.TabIndex = 1
        Me.lbTittle.Text = "FOOD ODERING SYSTEM"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(401, 206)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(36, 38)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "+"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(576, 206)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(37, 38)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "-"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'txt1
        '
        Me.txt1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1.Location = New System.Drawing.Point(471, 206)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(68, 30)
        Me.txt1.TabIndex = 4
        '
        'txt3
        '
        Me.txt3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt3.Location = New System.Drawing.Point(471, 312)
        Me.txt3.Name = "txt3"
        Me.txt3.Size = New System.Drawing.Size(68, 30)
        Me.txt3.TabIndex = 7
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(576, 308)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(37, 38)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "-"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(401, 308)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(36, 38)
        Me.Button5.TabIndex = 5
        Me.Button5.Text = "+"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'txt5
        '
        Me.txt5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt5.Location = New System.Drawing.Point(471, 424)
        Me.txt5.Name = "txt5"
        Me.txt5.Size = New System.Drawing.Size(68, 30)
        Me.txt5.TabIndex = 13
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(576, 420)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(37, 38)
        Me.Button6.TabIndex = 12
        Me.Button6.Text = "-"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(401, 420)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(36, 38)
        Me.Button7.TabIndex = 11
        Me.Button7.Text = "+"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'txt4
        '
        Me.txt4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt4.Location = New System.Drawing.Point(471, 367)
        Me.txt4.Name = "txt4"
        Me.txt4.Size = New System.Drawing.Size(68, 30)
        Me.txt4.TabIndex = 10
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(576, 367)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(37, 38)
        Me.Button8.TabIndex = 9
        Me.Button8.Text = "-"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(401, 367)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(36, 38)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "+"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'txt9
        '
        Me.txt9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt9.Location = New System.Drawing.Point(471, 696)
        Me.txt9.Name = "txt9"
        Me.txt9.Size = New System.Drawing.Size(68, 30)
        Me.txt9.TabIndex = 25
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(576, 692)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(37, 38)
        Me.Button10.TabIndex = 24
        Me.Button10.Text = "-"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(401, 692)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(36, 38)
        Me.Button11.TabIndex = 23
        Me.Button11.Text = "+"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'txt8
        '
        Me.txt8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt8.Location = New System.Drawing.Point(471, 639)
        Me.txt8.Name = "txt8"
        Me.txt8.Size = New System.Drawing.Size(68, 30)
        Me.txt8.TabIndex = 22
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(576, 639)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(37, 38)
        Me.Button12.TabIndex = 21
        Me.Button12.Text = "-"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Location = New System.Drawing.Point(401, 639)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(36, 38)
        Me.Button13.TabIndex = 20
        Me.Button13.Text = "+"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'txt7
        '
        Me.txt7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt7.Location = New System.Drawing.Point(471, 584)
        Me.txt7.Name = "txt7"
        Me.txt7.Size = New System.Drawing.Size(68, 30)
        Me.txt7.TabIndex = 19
        '
        'Button14
        '
        Me.Button14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.Location = New System.Drawing.Point(576, 580)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(37, 38)
        Me.Button14.TabIndex = 18
        Me.Button14.Text = "-"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(401, 580)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(36, 38)
        Me.Button15.TabIndex = 17
        Me.Button15.Text = "+"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'txt6
        '
        Me.txt6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt6.Location = New System.Drawing.Point(471, 531)
        Me.txt6.Name = "txt6"
        Me.txt6.Size = New System.Drawing.Size(68, 30)
        Me.txt6.TabIndex = 16
        '
        'Button16
        '
        Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.Location = New System.Drawing.Point(576, 527)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(37, 38)
        Me.Button16.TabIndex = 15
        Me.Button16.Text = "-"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.Location = New System.Drawing.Point(401, 527)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(36, 38)
        Me.Button17.TabIndex = 14
        Me.Button17.Text = "+"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'txtTotal
        '
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.Location = New System.Drawing.Point(1285, 232)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(127, 30)
        Me.txtTotal.TabIndex = 26
        '
        'lblFood1
        '
        Me.lblFood1.AutoSize = True
        Me.lblFood1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFood1.Location = New System.Drawing.Point(27, 206)
        Me.lblFood1.Name = "lblFood1"
        Me.lblFood1.Size = New System.Drawing.Size(51, 25)
        Me.lblFood1.TabIndex = 27
        Me.lblFood1.Text = "Test"
        '
        'lblFood3
        '
        Me.lblFood3.AutoSize = True
        Me.lblFood3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFood3.Location = New System.Drawing.Point(27, 308)
        Me.lblFood3.Name = "lblFood3"
        Me.lblFood3.Size = New System.Drawing.Size(51, 25)
        Me.lblFood3.TabIndex = 28
        Me.lblFood3.Text = "Test"
        '
        'lblFood4
        '
        Me.lblFood4.AutoSize = True
        Me.lblFood4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFood4.Location = New System.Drawing.Point(27, 367)
        Me.lblFood4.Name = "lblFood4"
        Me.lblFood4.Size = New System.Drawing.Size(51, 25)
        Me.lblFood4.TabIndex = 29
        Me.lblFood4.Text = "Test"
        '
        'lblFood5
        '
        Me.lblFood5.AutoSize = True
        Me.lblFood5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFood5.Location = New System.Drawing.Point(27, 424)
        Me.lblFood5.Name = "lblFood5"
        Me.lblFood5.Size = New System.Drawing.Size(51, 25)
        Me.lblFood5.TabIndex = 30
        Me.lblFood5.Text = "Test"
        '
        'lblFood2
        '
        Me.lblFood2.AutoSize = True
        Me.lblFood2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFood2.Location = New System.Drawing.Point(27, 256)
        Me.lblFood2.Name = "lblFood2"
        Me.lblFood2.Size = New System.Drawing.Size(51, 25)
        Me.lblFood2.TabIndex = 34
        Me.lblFood2.Text = "Test"
        '
        'txt2
        '
        Me.txt2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2.Location = New System.Drawing.Point(471, 256)
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(68, 30)
        Me.txt2.TabIndex = 33
        '
        'Button18
        '
        Me.Button18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.Location = New System.Drawing.Point(576, 256)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(37, 38)
        Me.Button18.TabIndex = 32
        Me.Button18.Text = "-"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.Location = New System.Drawing.Point(401, 256)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(36, 38)
        Me.Button19.TabIndex = 31
        Me.Button19.Text = "+"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'lblFoodP2
        '
        Me.lblFoodP2.AutoSize = True
        Me.lblFoodP2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFoodP2.Location = New System.Drawing.Point(262, 256)
        Me.lblFoodP2.Name = "lblFoodP2"
        Me.lblFoodP2.Size = New System.Drawing.Size(51, 25)
        Me.lblFoodP2.TabIndex = 39
        Me.lblFoodP2.Text = "Test"
        '
        'lblFoodP5
        '
        Me.lblFoodP5.AutoSize = True
        Me.lblFoodP5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFoodP5.Location = New System.Drawing.Point(262, 424)
        Me.lblFoodP5.Name = "lblFoodP5"
        Me.lblFoodP5.Size = New System.Drawing.Size(51, 25)
        Me.lblFoodP5.TabIndex = 38
        Me.lblFoodP5.Text = "Test"
        '
        'lblFoodP4
        '
        Me.lblFoodP4.AutoSize = True
        Me.lblFoodP4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFoodP4.Location = New System.Drawing.Point(262, 367)
        Me.lblFoodP4.Name = "lblFoodP4"
        Me.lblFoodP4.Size = New System.Drawing.Size(51, 25)
        Me.lblFoodP4.TabIndex = 37
        Me.lblFoodP4.Text = "Test"
        '
        'lblFoodP3
        '
        Me.lblFoodP3.AutoSize = True
        Me.lblFoodP3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFoodP3.Location = New System.Drawing.Point(262, 308)
        Me.lblFoodP3.Name = "lblFoodP3"
        Me.lblFoodP3.Size = New System.Drawing.Size(51, 25)
        Me.lblFoodP3.TabIndex = 36
        Me.lblFoodP3.Text = "Test"
        '
        'lblFoodP1
        '
        Me.lblFoodP1.AutoSize = True
        Me.lblFoodP1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFoodP1.Location = New System.Drawing.Point(262, 206)
        Me.lblFoodP1.Name = "lblFoodP1"
        Me.lblFoodP1.Size = New System.Drawing.Size(51, 25)
        Me.lblFoodP1.TabIndex = 35
        Me.lblFoodP1.Text = "Test"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(27, 161)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(99, 25)
        Me.Label6.TabIndex = 40
        Me.Label6.Text = "Food Item"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(248, 161)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 25)
        Me.Label7.TabIndex = 41
        Me.Label7.Text = "Price"
        '
        'Calculate
        '
        Me.Calculate.Location = New System.Drawing.Point(932, 754)
        Me.Calculate.Name = "Calculate"
        Me.Calculate.Size = New System.Drawing.Size(148, 38)
        Me.Calculate.TabIndex = 42
        Me.Calculate.Text = "Calculate"
        Me.Calculate.UseVisualStyleBackColor = True
        '
        'txtTax
        '
        Me.txtTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTax.Location = New System.Drawing.Point(1285, 344)
        Me.txtTax.Name = "txtTax"
        Me.txtTax.Size = New System.Drawing.Size(127, 30)
        Me.txtTax.TabIndex = 43
        '
        'txtNet
        '
        Me.txtNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNet.Location = New System.Drawing.Point(1285, 456)
        Me.txtNet.Name = "txtNet"
        Me.txtNet.Size = New System.Drawing.Size(127, 30)
        Me.txtNet.TabIndex = 44
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(1147, 754)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(148, 38)
        Me.Button20.TabIndex = 45
        Me.Button20.Text = "Payment"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(1922, 1055)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.txtNet)
        Me.Controls.Add(Me.txtTax)
        Me.Controls.Add(Me.Calculate)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblFoodP2)
        Me.Controls.Add(Me.lblFoodP5)
        Me.Controls.Add(Me.lblFoodP4)
        Me.Controls.Add(Me.lblFoodP3)
        Me.Controls.Add(Me.lblFoodP1)
        Me.Controls.Add(Me.lblFood2)
        Me.Controls.Add(Me.txt2)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.lblFood5)
        Me.Controls.Add(Me.lblFood4)
        Me.Controls.Add(Me.lblFood3)
        Me.Controls.Add(Me.lblFood1)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.txt9)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.txt8)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.txt7)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.txt6)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.txt5)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.txt4)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.txt3)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmMain"
        Me.Text = "Calculate"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents lbTittle As Label
    Friend WithEvents lbluserid As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents txt1 As TextBox
    Friend WithEvents txt3 As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents txt5 As TextBox
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents txt4 As TextBox
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents txt9 As TextBox
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents txt8 As TextBox
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents txt7 As TextBox
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents txt6 As TextBox
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents lblFood1 As Label
    Friend WithEvents lblFood3 As Label
    Friend WithEvents lblFood4 As Label
    Friend WithEvents lblFood5 As Label
    Friend WithEvents lblFood2 As Label
    Friend WithEvents txt2 As TextBox
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents lblFoodP2 As Label
    Friend WithEvents lblFoodP5 As Label
    Friend WithEvents lblFoodP4 As Label
    Friend WithEvents lblFoodP3 As Label
    Friend WithEvents lblFoodP1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Calculate As Button
    Friend WithEvents txtTax As TextBox
    Friend WithEvents txtNet As TextBox
    Friend WithEvents Button20 As Button
End Class
