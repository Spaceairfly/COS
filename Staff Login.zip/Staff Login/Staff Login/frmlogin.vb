﻿Imports System.Data.SqlClient

Public Class frmlogin
    Public loginuser As String
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand

        Try
            'change the data source and initial catalog according to your sql server engine and data base
            con.ConnectionString = "Server=LAPTOP-82GE14HQ;Database=VBNCOS;Trusted_Connection=True;"
            con.Open()
            cmd.Connection = con
            'change the data fields names and table according to your database
            cmd.CommandText = " SELECT user_username, user_userpassword FROM tbluser WHERE (user_username = '" & txtusername.Text & "' ) AND (user_userpassword = '" & txtpassword.Text & "')"

            Dim lrd As SqlDataReader = cmd.ExecuteReader()
            If lrd.HasRows Then
                MessageBox.Show("Logged in successfully as " & txtusername.Text, "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                loginuser = txtusername.Text
                frmMain.Show()
                Me.Hide()
                'Clear all fields
                txtpassword.Text = ""
                txtusername.Text = ""
            Else
                MessageBox.Show("Username and Password do not match..", "Authentication Failure", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                'Clear all fields
                txtpassword.Text = ""
                txtusername.Text = ""
            End If



        Catch ex As Exception
            MessageBox.Show("Error while connecting to SQL Server." & ex.Message)

        Finally
            con.Close() 'Whether there is error or not. Close the connection.

        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub frmlogin_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtusername.Focus()
    End Sub
End Class
