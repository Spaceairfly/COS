﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTotalPayable = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl50 = New System.Windows.Forms.Label()
        Me.lbl20 = New System.Windows.Forms.Label()
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl050 = New System.Windows.Forms.Label()
        Me.lbl020 = New System.Windows.Forms.Label()
        Me.lbl010 = New System.Windows.Forms.Label()
        Me.txt50 = New System.Windows.Forms.TextBox()
        Me.txt20 = New System.Windows.Forms.TextBox()
        Me.txt10 = New System.Windows.Forms.TextBox()
        Me.txt5 = New System.Windows.Forms.TextBox()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.txt050 = New System.Windows.Forms.TextBox()
        Me.txt020 = New System.Windows.Forms.TextBox()
        Me.txt010 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblRemittance = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblbalance = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblt020 = New System.Windows.Forms.Label()
        Me.lblt050 = New System.Windows.Forms.Label()
        Me.lblt1 = New System.Windows.Forms.Label()
        Me.lblt5 = New System.Windows.Forms.Label()
        Me.lblt10 = New System.Windows.Forms.Label()
        Me.lblt20 = New System.Windows.Forms.Label()
        Me.lblt50 = New System.Windows.Forms.Label()
        Me.lblt010 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblTotalPayable
        '
        Me.lblTotalPayable.AutoSize = True
        Me.lblTotalPayable.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalPayable.Location = New System.Drawing.Point(693, 124)
        Me.lblTotalPayable.Name = "lblTotalPayable"
        Me.lblTotalPayable.Size = New System.Drawing.Size(23, 25)
        Me.lblTotalPayable.TabIndex = 0
        Me.lblTotalPayable.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(526, 124)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(143, 25)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Total Payable :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(81, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(143, 25)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Total Payable :"
        '
        'lbl50
        '
        Me.lbl50.AutoSize = True
        Me.lbl50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl50.Location = New System.Drawing.Point(81, 129)
        Me.lbl50.Name = "lbl50"
        Me.lbl50.Size = New System.Drawing.Size(96, 25)
        Me.lbl50.TabIndex = 3
        Me.lbl50.Text = "RM 50.00"
        '
        'lbl20
        '
        Me.lbl20.AutoSize = True
        Me.lbl20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl20.Location = New System.Drawing.Point(81, 190)
        Me.lbl20.Name = "lbl20"
        Me.lbl20.Size = New System.Drawing.Size(143, 25)
        Me.lbl20.TabIndex = 4
        Me.lbl20.Text = "Total Payable :"
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10.Location = New System.Drawing.Point(81, 244)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(143, 25)
        Me.lbl10.TabIndex = 5
        Me.lbl10.Text = "Total Payable :"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5.Location = New System.Drawing.Point(81, 298)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(143, 25)
        Me.lbl5.TabIndex = 6
        Me.lbl5.Text = "Total Payable :"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(81, 357)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(143, 25)
        Me.lbl1.TabIndex = 7
        Me.lbl1.Text = "Total Payable :"
        '
        'lbl050
        '
        Me.lbl050.AutoSize = True
        Me.lbl050.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl050.Location = New System.Drawing.Point(81, 412)
        Me.lbl050.Name = "lbl050"
        Me.lbl050.Size = New System.Drawing.Size(143, 25)
        Me.lbl050.TabIndex = 8
        Me.lbl050.Text = "Total Payable :"
        '
        'lbl020
        '
        Me.lbl020.AutoSize = True
        Me.lbl020.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl020.Location = New System.Drawing.Point(81, 467)
        Me.lbl020.Name = "lbl020"
        Me.lbl020.Size = New System.Drawing.Size(143, 25)
        Me.lbl020.TabIndex = 9
        Me.lbl020.Text = "Total Payable :"
        '
        'lbl010
        '
        Me.lbl010.AutoSize = True
        Me.lbl010.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl010.Location = New System.Drawing.Point(81, 521)
        Me.lbl010.Name = "lbl010"
        Me.lbl010.Size = New System.Drawing.Size(143, 25)
        Me.lbl010.TabIndex = 10
        Me.lbl010.Text = "Total Payable :"
        '
        'txt50
        '
        Me.txt50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt50.Location = New System.Drawing.Point(244, 129)
        Me.txt50.Name = "txt50"
        Me.txt50.Size = New System.Drawing.Size(100, 30)
        Me.txt50.TabIndex = 11
        '
        'txt20
        '
        Me.txt20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt20.Location = New System.Drawing.Point(244, 185)
        Me.txt20.Name = "txt20"
        Me.txt20.Size = New System.Drawing.Size(100, 30)
        Me.txt20.TabIndex = 12
        '
        'txt10
        '
        Me.txt10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt10.Location = New System.Drawing.Point(244, 239)
        Me.txt10.Name = "txt10"
        Me.txt10.Size = New System.Drawing.Size(100, 30)
        Me.txt10.TabIndex = 13
        '
        'txt5
        '
        Me.txt5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt5.Location = New System.Drawing.Point(244, 293)
        Me.txt5.Name = "txt5"
        Me.txt5.Size = New System.Drawing.Size(100, 30)
        Me.txt5.TabIndex = 14
        '
        'txt1
        '
        Me.txt1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1.Location = New System.Drawing.Point(244, 352)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(100, 30)
        Me.txt1.TabIndex = 15
        '
        'txt050
        '
        Me.txt050.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt050.Location = New System.Drawing.Point(244, 407)
        Me.txt050.Name = "txt050"
        Me.txt050.Size = New System.Drawing.Size(100, 30)
        Me.txt050.TabIndex = 16
        '
        'txt020
        '
        Me.txt020.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt020.Location = New System.Drawing.Point(244, 462)
        Me.txt020.Name = "txt020"
        Me.txt020.Size = New System.Drawing.Size(100, 30)
        Me.txt020.TabIndex = 17
        '
        'txt010
        '
        Me.txt010.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt010.Location = New System.Drawing.Point(244, 516)
        Me.txt010.Name = "txt010"
        Me.txt010.Size = New System.Drawing.Size(100, 30)
        Me.txt010.TabIndex = 18
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(500, 180)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(169, 25)
        Me.Label11.TabIndex = 28
        Me.Label11.Text = "Total Remittance :"
        '
        'lblRemittance
        '
        Me.lblRemittance.AutoSize = True
        Me.lblRemittance.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRemittance.Location = New System.Drawing.Point(693, 180)
        Me.lblRemittance.Name = "lblRemittance"
        Me.lblRemittance.Size = New System.Drawing.Size(23, 25)
        Me.lblRemittance.TabIndex = 29
        Me.lblRemittance.Text = "0"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(500, 267)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(132, 25)
        Me.Label13.TabIndex = 30
        Me.Label13.Text = "Total Balance"
        '
        'lblbalance
        '
        Me.lblbalance.AutoSize = True
        Me.lblbalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbalance.Location = New System.Drawing.Point(693, 267)
        Me.lblbalance.Name = "lblbalance"
        Me.lblbalance.Size = New System.Drawing.Size(23, 25)
        Me.lblbalance.TabIndex = 31
        Me.lblbalance.Text = "0"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(500, 227)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(288, 25)
        Me.Label15.TabIndex = 32
        Me.Label15.Text = "======================="
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(500, 301)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(288, 25)
        Me.Label16.TabIndex = 33
        Me.Label16.Text = "======================="
        '
        'lblt020
        '
        Me.lblt020.AutoSize = True
        Me.lblt020.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblt020.Location = New System.Drawing.Point(360, 465)
        Me.lblt020.Name = "lblt020"
        Me.lblt020.Size = New System.Drawing.Size(23, 25)
        Me.lblt020.TabIndex = 40
        Me.lblt020.Text = "0"
        '
        'lblt050
        '
        Me.lblt050.AutoSize = True
        Me.lblt050.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblt050.Location = New System.Drawing.Point(360, 411)
        Me.lblt050.Name = "lblt050"
        Me.lblt050.Size = New System.Drawing.Size(23, 25)
        Me.lblt050.TabIndex = 39
        Me.lblt050.Text = "0"
        '
        'lblt1
        '
        Me.lblt1.AutoSize = True
        Me.lblt1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblt1.Location = New System.Drawing.Point(360, 356)
        Me.lblt1.Name = "lblt1"
        Me.lblt1.Size = New System.Drawing.Size(23, 25)
        Me.lblt1.TabIndex = 38
        Me.lblt1.Text = "0"
        '
        'lblt5
        '
        Me.lblt5.AutoSize = True
        Me.lblt5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblt5.Location = New System.Drawing.Point(360, 301)
        Me.lblt5.Name = "lblt5"
        Me.lblt5.Size = New System.Drawing.Size(23, 25)
        Me.lblt5.TabIndex = 37
        Me.lblt5.Text = "0"
        '
        'lblt10
        '
        Me.lblt10.AutoSize = True
        Me.lblt10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblt10.Location = New System.Drawing.Point(360, 242)
        Me.lblt10.Name = "lblt10"
        Me.lblt10.Size = New System.Drawing.Size(23, 25)
        Me.lblt10.TabIndex = 36
        Me.lblt10.Text = "0"
        '
        'lblt20
        '
        Me.lblt20.AutoSize = True
        Me.lblt20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblt20.Location = New System.Drawing.Point(360, 188)
        Me.lblt20.Name = "lblt20"
        Me.lblt20.Size = New System.Drawing.Size(23, 25)
        Me.lblt20.TabIndex = 35
        Me.lblt20.Text = "0"
        '
        'lblt50
        '
        Me.lblt50.AutoSize = True
        Me.lblt50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblt50.Location = New System.Drawing.Point(360, 134)
        Me.lblt50.Name = "lblt50"
        Me.lblt50.Size = New System.Drawing.Size(23, 25)
        Me.lblt50.TabIndex = 34
        Me.lblt50.Text = "0"
        '
        'lblt010
        '
        Me.lblt010.AutoSize = True
        Me.lblt010.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblt010.Location = New System.Drawing.Point(360, 516)
        Me.lblt010.Name = "lblt010"
        Me.lblt010.Size = New System.Drawing.Size(23, 25)
        Me.lblt010.TabIndex = 41
        Me.lblt010.Text = "0"
        '
        'frmPay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(876, 592)
        Me.Controls.Add(Me.lblt010)
        Me.Controls.Add(Me.lblt020)
        Me.Controls.Add(Me.lblt050)
        Me.Controls.Add(Me.lblt1)
        Me.Controls.Add(Me.lblt5)
        Me.Controls.Add(Me.lblt10)
        Me.Controls.Add(Me.lblt20)
        Me.Controls.Add(Me.lblt50)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.lblbalance)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.lblRemittance)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txt010)
        Me.Controls.Add(Me.txt020)
        Me.Controls.Add(Me.txt050)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.txt5)
        Me.Controls.Add(Me.txt10)
        Me.Controls.Add(Me.txt20)
        Me.Controls.Add(Me.txt50)
        Me.Controls.Add(Me.lbl010)
        Me.Controls.Add(Me.lbl020)
        Me.Controls.Add(Me.lbl050)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.lbl20)
        Me.Controls.Add(Me.lbl50)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTotalPayable)
        Me.Name = "frmPay"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTotalPayable As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lbl50 As Label
    Friend WithEvents lbl20 As Label
    Friend WithEvents lbl10 As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents lbl050 As Label
    Friend WithEvents lbl020 As Label
    Friend WithEvents lbl010 As Label
    Friend WithEvents txt50 As TextBox
    Friend WithEvents txt20 As TextBox
    Friend WithEvents txt10 As TextBox
    Friend WithEvents txt5 As TextBox
    Friend WithEvents txt1 As TextBox
    Friend WithEvents txt050 As TextBox
    Friend WithEvents txt020 As TextBox
    Friend WithEvents txt010 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents lblRemittance As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblbalance As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lblt020 As Label
    Friend WithEvents lblt050 As Label
    Friend WithEvents lblt1 As Label
    Friend WithEvents lblt5 As Label
    Friend WithEvents lblt10 As Label
    Friend WithEvents lblt20 As Label
    Friend WithEvents lblt50 As Label
    Friend WithEvents lblt010 As Label
End Class
