﻿Public Class frmPay
    Dim DblTP, dblR, dblBal As Double

    Private Sub txt20_TextChanged(sender As Object, e As EventArgs) Handles txt20.TextChanged
        lblt20.Text = Str(Val(txt20.Text) * 20)
        lblRemittance.Text = Str(Val(lblt50.Text) + Val(lblt20.Text) + Val(lblt10.Text) + Val(lblt1.Text) + Val(lblt050.Text) + Val(lblt020.Text) + Val(lblt010.Text))
        lblbalance.Text = String.Format("{0:n2}", (Val(lblRemittance.Text) - Val(lblTotalPayable.Text)))
    End Sub

    Private Sub txt10_TextChanged(sender As Object, e As EventArgs) Handles txt10.TextChanged
        lblt10.Text = Str(Val(txt10.Text) * 10)
        lblRemittance.Text = Str(Val(lblt50.Text) + Val(lblt20.Text) + Val(lblt10.Text) + Val(lblt1.Text) + Val(lblt050.Text) + Val(lblt020.Text) + Val(lblt010.Text))
        lblbalance.Text = String.Format("{0:n2}", (Val(lblRemittance.Text) - Val(lblTotalPayable.Text)))
    End Sub

    Private Sub txt5_TextChanged(sender As Object, e As EventArgs) Handles txt5.TextChanged
        lblt5.Text = Str(Val(txt5.Text) * 5)
        lblRemittance.Text = Str(Val(lblt50.Text) + Val(lblt20.Text) + Val(lblt10.Text) + Val(lblt1.Text) + Val(lblt050.Text) + Val(lblt020.Text) + Val(lblt010.Text))
        lblbalance.Text = String.Format("{0:n2}", (Val(lblRemittance.Text) - Val(lblTotalPayable.Text)))
    End Sub

    Private Sub txt1_TextChanged(sender As Object, e As EventArgs) Handles txt1.TextChanged
        lblt1.Text = Str(Val(txt1.Text) * 1)
        lblRemittance.Text = Str(Val(lblt50.Text) + Val(lblt20.Text) + Val(lblt10.Text) + Val(lblt1.Text) + Val(lblt050.Text) + Val(lblt020.Text) + Val(lblt010.Text))
        lblbalance.Text = String.Format("{0:n2}", (Val(lblRemittance.Text) - Val(lblTotalPayable.Text)))
    End Sub

    Private Sub txt050_TextChanged(sender As Object, e As EventArgs) Handles txt050.TextChanged
        lblt050.Text = Str(Val(txt050.Text) * 0.5)
        lblRemittance.Text = Str(Val(lblt50.Text) + Val(lblt20.Text) + Val(lblt10.Text) + Val(lblt1.Text) + Val(lblt050.Text) + Val(lblt020.Text) + Val(lblt010.Text))
        lblbalance.Text = String.Format("{0:n2}", (Val(lblRemittance.Text) - Val(lblTotalPayable.Text)))
    End Sub

    Private Sub txt020_TextChanged(sender As Object, e As EventArgs) Handles txt020.TextChanged
        lblt020.Text = Str(Val(txt020.Text) * 0.2)
        lblRemittance.Text = Str(Val(lblt50.Text) + Val(lblt20.Text) + Val(lblt10.Text) + Val(lblt1.Text) + Val(lblt050.Text) + Val(lblt020.Text) + Val(lblt010.Text))
        lblbalance.Text = String.Format("{0:n2}", (Val(lblRemittance.Text) - Val(lblTotalPayable.Text)))
    End Sub

    Private Sub txt010_TextChanged(sender As Object, e As EventArgs) Handles txt010.TextChanged
        lblt010.Text = Str(Val(txt010.Text) * 0.1)
        lblRemittance.Text = Str(Val(lblt50.Text) + Val(lblt20.Text) + Val(lblt10.Text) + Val(lblt1.Text) + Val(lblt050.Text) + Val(lblt020.Text) + Val(lblt010.Text))
        lblbalance.Text = String.Format("{0:n2}", (Val(lblRemittance.Text) - Val(lblTotalPayable.Text)))
    End Sub

    Private Sub txt50_TextChanged(sender As Object, e As EventArgs) Handles txt50.TextChanged
        lblt50.Text = Str(Val(txt50.Text) * 50)
        lblRemittance.Text = Str(Val(lblt50.Text) + Val(lblt20.Text) + Val(lblt10.Text) + Val(lblt1.Text) + Val(lblt050.Text) + Val(lblt020.Text) + Val(lblt010.Text))
        lblbalance.Text = String.Format("{0:n2}", (Val(lblRemittance.Text) - Val(lblTotalPayable.Text)))
    End Sub

    Private Sub frmPay_Load(sender As Object, e As EventArgs) Handles Me.Load
        lblTotalPayable.Text = Str(frmMain.TotalPayable)
        txt50.Text = 0 : txt20.Text = 0 : txt10.Text = 0 : txt5.Text = 0 : txt1.Text = 0 : txt050.Text = 0 : txt020.Text = 0 : txt010.Text = 0
    End Sub
End Class